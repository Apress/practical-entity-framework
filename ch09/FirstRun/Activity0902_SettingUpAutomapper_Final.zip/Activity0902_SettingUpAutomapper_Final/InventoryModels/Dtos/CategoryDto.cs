﻿namespace InventoryModels.Dtos
{
    public class CategoryDto
    {
        
    }
}
