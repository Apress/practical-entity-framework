﻿CREATE OR ALTER FUNCTION dbo.ItemNamesPipeDelimitedString
(
	@IsActive BIT
)
RETURNS VARCHAR(2500)
AS
BEGIN
	DECLARE @allItems VARCHAR(2500) 
	
	SELECT @allItems = COALESCE(@allItems + '|', '') + [Name] 
	FROM Items 
	WHERE IsActive = @IsActive
	GROUP BY [Name] 
	ORDER BY [Name] 

	RETURN @allItems
END
GO 
