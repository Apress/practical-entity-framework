﻿namespace InventoryModels.Dtos
{
    public class CategoryColorDto
    {
        public string Color { get; set; }
    }
}
