﻿namespace AWEFDataAccessLayer.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EncryptionMigration_Step7_DeleteBackupColumns : DbMigration
    {
        public override void Up()
        {
            DropColumn("HumanResources.Employee", "NationalIDNumberBackup");
            DropColumn("HumanResources.Employee", "JobTitleBackup");
            DropColumn("HumanResources.Employee", "BirthDateBackup");
            DropColumn("HumanResources.Employee", "MaritalStatusBackup");
            DropColumn("HumanResources.Employee", "GenderBackup");
            DropColumn("HumanResources.Employee", "HireDateBackup");
        }
        
        public override void Down()
        {
            AddColumn("HumanResources.Employee", "HireDateBackup", c => c.DateTime(nullable: false, storeType: "date"));
            AddColumn("HumanResources.Employee", "GenderBackup", c => c.String(nullable: false, maxLength: 1));
            AddColumn("HumanResources.Employee", "MaritalStatusBackup", c => c.String(maxLength: 1));
            AddColumn("HumanResources.Employee", "BirthDateBackup", c => c.DateTime(nullable: false, storeType: "date"));
            AddColumn("HumanResources.Employee", "JobTitleBackup", c => c.String(maxLength: 50));
            AddColumn("HumanResources.Employee", "NationalIDNumberBackup", c => c.String(maxLength: 15));
        }
    }
}
