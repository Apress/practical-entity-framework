﻿namespace AWEFDataAccessLayer.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EncryptionMigration_Step4_DropConstraints : DbMigration
    {
        public override void Up()
        {
            SqlResource(@"AWEFDataAccessLayer.Migrations.Scripts.EncryptionMigration.003_DropConstraints.sql");
        }
        
        public override void Down()
        {
        }
    }
}
