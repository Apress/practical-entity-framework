﻿namespace AWEFDataAccessLayer.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EncryptionMigration_Step3_CertsAndKeysGeneration : DbMigration
    {
        public override void Up()
        {
            SqlResource(@"AWEFDataAccessLayer.Migrations.Scripts.EncryptionMigration.002_CertsAndKeysGeneration.sql");
        }
        
        public override void Down()
        {
        }
    }
}
