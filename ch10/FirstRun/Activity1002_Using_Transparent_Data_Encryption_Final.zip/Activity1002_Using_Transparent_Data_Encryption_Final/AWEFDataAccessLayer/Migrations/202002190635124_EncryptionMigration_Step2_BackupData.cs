﻿namespace AWEFDataAccessLayer.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EncryptionMigration_Step2_BackupData : DbMigration
    {
        public override void Up()
        {
            SqlResource(@"AWEFDataAccessLayer.Migrations.Scripts.EncryptionMigration.001_BackupData.sql");
        }
        
        public override void Down()
        {
            //nothing to do here.
        }
    }
}
