﻿ALTER TABLE [HumanResources].[Employee] DROP CONSTRAINT [CK_Employee_MaritalStatus]
GO
ALTER TABLE [HumanResources].[Employee] DROP CONSTRAINT [CK_Employee_HireDate]
GO
ALTER TABLE [HumanResources].[Employee] DROP CONSTRAINT [DF__Employee__HireDa__05F8DC4F]
GO
ALTER TABLE [HumanResources].[Employee] DROP CONSTRAINT [CK_Employee_Gender]
GO
ALTER TABLE [HumanResources].[Employee] DROP CONSTRAINT [DF__Employee__Gender__0504B816]
GO
ALTER TABLE [HumanResources].[Employee] DROP CONSTRAINT [CK_Employee_BirthDate]
GO
ALTER TABLE [HumanResources].[Employee] DROP CONSTRAINT [DF__Employee__BirthD__041093DD]
GO
DROP INDEX [AK_Employee_NationalIDNumber] ON [HumanResources].[Employee]
GO
