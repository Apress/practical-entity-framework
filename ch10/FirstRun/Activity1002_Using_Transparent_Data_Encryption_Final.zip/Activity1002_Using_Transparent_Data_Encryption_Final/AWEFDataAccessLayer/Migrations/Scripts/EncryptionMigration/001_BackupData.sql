﻿UPDATE [HumanResources].[Employee]
   SET [NationalIDNumberBackup] = [NationalIDNumber] 
      ,[JobTitleBackup] = [JobTitle]
      ,[BirthDateBackup] = [BirthDate] 
      ,[MaritalStatusBackup] = [MaritalStatus] 
      ,[GenderBackup] = [Gender]
      ,[HireDateBackup] = [HireDate]
GO