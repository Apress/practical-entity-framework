﻿OPEN SYMMETRIC KEY AW_ColumnKey
	DECRYPTION BY CERTIFICATE AW_tdeCert;

UPDATE [HumanResources].[Employee]
   SET [NationalIDNumber] = encryptByKey(Key_GUID('AW_ColumnKey'), CONVERT(varbinary(max), [NationalIDNumberBackup]))  
      ,[JobTitle] = encryptByKey(Key_GUID('AW_ColumnKey'), CONVERT(varbinary(max), [JobTitleBackup]))  
      ,[BirthDate] = encryptByKey(Key_GUID('AW_ColumnKey'), CONVERT(varbinary(max), [BirthDateBackup]))  
      ,[MaritalStatus] = encryptByKey(Key_GUID('AW_ColumnKey'), CONVERT(varbinary(max), [MaritalStatusBackup]))  
      ,[Gender] = encryptByKey(Key_GUID('AW_ColumnKey'), CONVERT(varbinary(max), [GenderBackup]))  
      ,[HireDate] = encryptByKey(Key_GUID('AW_ColumnKey'), CONVERT(varbinary(max), [HireDateBackup]))  
GO

CLOSE ALL SYMMETRIC KEYS
