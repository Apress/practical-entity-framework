﻿IF NOT EXISTS (SELECT * FROM sys.symmetric_keys WHERE symmetric_key_id = 101)
BEGIN
	CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'Password#123'
END
GO

CREATE CERTIFICATE AW_tdeCert WITH SUBJECT = 'AdventureWorks TDE Certificate'
GO

BACKUP CERTIFICATE AW_tdeCert TO FILE = 'C:\Data\DatabaseKeys\AW_tdeCert.crt'
WITH PRIVATE KEY
(
	FILE = 'C:\Data\DatabaseKeys\AW_tdeCert_PrivateKey.crt',
	ENCRYPTION BY PASSWORD = 'Password#123'
)
GO

CREATE SYMMETRIC KEY AW_ColumnKey
	WITH ALGORITHM = AES_256
	ENCRYPTION BY CERTIFICATE AW_tdeCert;
GO