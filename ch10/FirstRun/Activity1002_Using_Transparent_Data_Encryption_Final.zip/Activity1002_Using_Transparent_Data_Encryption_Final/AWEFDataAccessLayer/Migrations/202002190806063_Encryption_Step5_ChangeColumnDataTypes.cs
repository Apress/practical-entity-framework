﻿namespace AWEFDataAccessLayer.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Encryption_Step5_ChangeColumnDataTypes : DbMigration
    {
        public override void Up()
        {
            AddColumn("HumanResources.Employee", "NationalIDNumberTemp", c => c.Binary(nullable: false));
            Sql("UPDATE HumanResources.Employee SET NationalIDNumberTemp = CONVERT(varbinary, NationalIdNumber)");
            DropColumn("HumanResources.Employee", "NationalIDNumber");
            RenameColumn("HumanResources.Employee", "NationalIDNumberTemp", "NationalIDNumber");
            AddColumn("HumanResources.Employee", "JobTitleTemp", c => c.Binary(nullable: false));
            Sql("UPDATE HumanResources.Employee SET JobTitleTemp = CONVERT(varbinary, JobTitle)");
            DropColumn("HumanResources.Employee", "JobTitle");
            RenameColumn("HumanResources.Employee", "JobTitleTemp", "JobTitle");
            AddColumn("HumanResources.Employee", "MaritalStatusTemp", c => c.Binary(nullable: false));
            Sql("UPDATE HumanResources.Employee SET MaritalStatusTemp = CONVERT(varbinary, MaritalStatus)");
            DropColumn("HumanResources.Employee", "MaritalStatus");
            RenameColumn("HumanResources.Employee", "MaritalStatusTemp", "MaritalStatus");
            AddColumn("HumanResources.Employee", "GenderTemp", c => c.Binary(nullable: false));
            Sql("UPDATE HumanResources.Employee SET GenderTemp = CONVERT(varbinary, Gender)");
            DropColumn("HumanResources.Employee", "Gender");
            RenameColumn("HumanResources.Employee", "GenderTemp", "Gender");
            AddColumn("HumanResources.Employee", "HireDateTemp", c => c.Binary());
            Sql("UPDATE HumanResources.Employee SET HireDateTemp = CONVERT(varbinary, HireDate)");
            DropColumn("HumanResources.Employee", "HireDate");
            RenameColumn("HumanResources.Employee", "HireDateTemp", "HireDate");
            AddColumn("HumanResources.Employee", "BirthDateTemp", c => c.Binary());
            Sql("UPDATE HumanResources.Employee SET BirthDateTemp = CONVERT(varbinary, BirthDate)");
            DropColumn("HumanResources.Employee", "BirthDate");
            RenameColumn("HumanResources.Employee", "BirthDateTemp", "BirthDate");
        }

        public override void Down()
        {
            /*
            AlterColumn("HumanResources.Employee", "HireDate", c => c.DateTime(nullable: false, storeType: "date"));
            AlterColumn("HumanResources.Employee", "Gender", c => c.String(nullable: false, maxLength: 1, fixedLength: true));
            AlterColumn("HumanResources.Employee", "MaritalStatus", c => c.String(nullable: false, maxLength: 1, fixedLength: true));
            AlterColumn("HumanResources.Employee", "BirthDate", c => c.DateTime(nullable: false, storeType: "date"));
            AlterColumn("HumanResources.Employee", "JobTitle", c => c.String(nullable: false, maxLength: 50));
            AlterColumn("HumanResources.Employee", "NationalIDNumber", c => c.String(nullable: false, maxLength: 15));
            */
        }
    }
}
