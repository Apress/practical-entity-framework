﻿namespace AWEFDataAccessLayer.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class EncryptionMigration_Step6_EncryptBackupDataIntoOriginalColumns : DbMigration
    {
        public override void Up()
        {
            SqlResource(@"AWEFDataAccessLayer.Migrations.Scripts.EncryptionMigration.004_EncryptAndInsertBackupData.sql");
        }
        
        public override void Down()
        {
        }
    }
}
