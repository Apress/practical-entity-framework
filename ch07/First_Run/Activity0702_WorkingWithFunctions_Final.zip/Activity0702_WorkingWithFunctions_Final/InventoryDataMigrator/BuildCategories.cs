﻿using InventoryDatabaseCore;
using InventoryModels;
using System;
using System.Linq;

namespace InventoryDataMigrator
{
    public class BuildCategories
    {
        private readonly InventoryDbContext _context;

        public BuildCategories(InventoryDbContext context)
        {
            _context = context;
        }

        public void ExecuteSeed()
        {
            if (_context.Categories.Count() == 0)
            {
                _context.Categories.AddRange(
                    new Category()
                    {
                        CreatedDate = DateTime.Now,
                        IsActive = true,
                        IsDeleted = false,
                        Name = "Movies",
                        CategoryColor = new CategoryColor() { ColorValue = "Blue" }
                    },
                    new Category()
                    {
                        CreatedDate = DateTime.Now,
                        IsActive = true,
                        IsDeleted = false,
                        Name = "Books",
                        CategoryColor = new CategoryColor() { ColorValue = "Red" }
                    },
                    new Category()
                    {
                        CreatedDate = DateTime.Now,
                        IsActive = true,
                        IsDeleted = false,
                        Name = "Games",
                        CategoryColor = new CategoryColor() { ColorValue = "Green" }
                    }
                );
                _context.SaveChanges();
            }
        }
    }
}
