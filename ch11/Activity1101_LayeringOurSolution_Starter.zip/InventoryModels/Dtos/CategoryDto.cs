﻿namespace InventoryModels.Dtos
{
    public class CategoryDto
    {
        public string Category { get; set; }
        public CategoryColorDto CategoryColor { get; set; }

    }
}
