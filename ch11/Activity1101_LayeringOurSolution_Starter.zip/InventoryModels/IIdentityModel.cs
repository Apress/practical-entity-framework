﻿namespace InventoryModels
{
    public interface IIdentityModel
    {
        public int Id { get; set; }   
    }
}
