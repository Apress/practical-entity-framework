﻿namespace InventoryModels.Dtos
{
    public class AllItemsPipeDelimitedStringDto
    {
        public string AllItems { get; set; } = "";
    }

}
