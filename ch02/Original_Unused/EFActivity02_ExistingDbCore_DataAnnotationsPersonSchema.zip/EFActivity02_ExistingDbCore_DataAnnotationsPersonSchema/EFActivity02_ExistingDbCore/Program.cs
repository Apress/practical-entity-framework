﻿using System;

namespace EFActivity02_ExistingDbCore
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
