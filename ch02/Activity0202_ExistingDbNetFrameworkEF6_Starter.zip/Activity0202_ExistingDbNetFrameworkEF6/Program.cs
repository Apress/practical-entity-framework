﻿namespace Activity0202_ExistingDbNetFrameworkEF6
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
